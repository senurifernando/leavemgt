<?php
include("controller.php");



if(isset($_POST["userRegister"])){
$id=0;
$fname=$_POST["First_Name"];
$lname=$_POST["Last_Name"];
$gender=$_POST["Gender"];
$designation=$_POST["Designation"];
$faculty=$_POST["Faculty"];
$department=$_POST["Department"];
$username=$_POST["Username"];
$password=$_POST["password_1"];
$cpassword=$_POST["password_2"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$address=$_POST["address"];

$data=array($id,$fname,$lname,$gender,$designation,$faculty,$department,$email,$phone,$address,$username);




$ob->save("user_profile");
$m=$ob->max("user_profile");

$data1=array(($m+1),$username,$password,$designation);

$ob->save($data,"user_profile");
$ob->save($data1,"login");
	header("location:Login FORM.php");
}



			if(isset($_POST["ResetPassword"])){

	 		 $username=$_POST["username"];
			 $password=$_POST["password"];

				$res=$ob->searchValueBy("login","UserID",$username);
					//print_r($res);
					$b=false;
					foreach ($res as $key => $value) {
					$b=true;
					}



if($b){
$ob->reset($username,$password);

}else{
header("location:ResetPassword.php");
}
	
	
	}

	/*	if(isset($_POST["Login"])){

		$userId=$_POST["username"];
		$password=$_POST["password"];


		$res=$ob->searchValueBy1("login","UserType");
			header("location:dashboard.php");
			 
	
		}*/

?>