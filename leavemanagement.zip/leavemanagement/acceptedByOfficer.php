
<?php
session_start();
$user=$_SESSION["user"];
$Department=$_SESSION["Department"];
$con= mysqli_connect("localhost","root","","leavemgt");
$result=mysqli_query($con,"SELECT * from user_profile where UserID='$user' ");
$Designation="null";
	while($row=mysqli_fetch_array($result)){
	$Designation=$row["Designation"];
	
	}


$result1=mysqli_query($con,"SELECT * from login where UserID='$user' ");
$id="null";
	while($row=mysqli_fetch_array($result1)){
	$id=$row["id"];
	
	}


?>


<div  class="col-9" >
<html>
<head>
	
</head>
<body>
	<form>
		
			<table border="1" width="100%">
			<tr>
				<th>Leave No</th>
				
				<th>Head of the department</th>
				<th>Officer Acting</th>
				<th>No of Days</th>
				<th>Reason</th>
				<th>Status</th>
				
			</tr>
		<?php

if ($con){
	
}else{
	echo "Failure";
}
$s="N/A";
	$result=mysqli_query($con,"SELECT * from leave_form where Designation='$Designation' and EmployeeID='$id' ");

	while($row=mysqli_fetch_array($result)){
	$id=$row["leave_no"];
		$a1=$row["EmployeeID"];
		$b2=$row["Designation"];
		$c3=$row["Department"];
		$d4=$row["HOD"];
		$e5=$row["Officer_acting"];
		$f6=$row["Days"];
		$g7=$row["Reason"];
		$h8=$row["Status"];
?>
	
			<tr>
				
				<td><?php echo "$id"; ?></td>
				<td><?php echo "$d4"; ?></td>
				<td><?php echo "$e5"; ?></td>
				<td><?php echo "$f6"; ?></td>
				<td><?php echo "$g7"; ?></td>
					<td><?php echo "$h8"; ?></td>
			
			</tr>
<?php } ?>
		</table>
	</form>
</body>
</html>
</div>