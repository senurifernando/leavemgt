<?php
include("db.php");



class RegisterAction extends db{
function save($a,$table){
$res=mysqli_query($this->connect(),"insert into $table values('".implode("','",array_values($a))."')");
if($res){
	echo"Successfully Saved";
}else{
	echo"Saving failed";
}
	
	
	
}

	function reset($u,$p){

		$res=mysqli_query($this->connect(),"update login set Password='$p' where UserID='$u' ");
	if($res){
	header("location:Login FORM.php");
}else{
		header("location:ResetPassword.php");
}
	}

	function searchValueBy($table,$field,$value){
	
			$res=mysqli_query($this->connect(),"select * from $table where $field='$value' ");
						$array=array();
						while($row=mysqli_fetch_assoc($res)){
							$array[]=$row;
						}


							return $array;
					}

	function search($table){
			$res=mysqli_query($this->connect(),"select * from $table");
						$array=array();
						while($row=mysqli_fetch_assoc($res)){
							$array[]=$row;
						}
							return $array;
					}
function max($table){
			$res=mysqli_query($this->connect(),"select * from $table");
						$array=array();
						while($row=mysqli_fetch_assoc($res)){
							$array[]=$row;
						}

$max=0;
						foreach ($array as $key => $value) {
							$id=$value["id"];
							if($max<$id){
								$max=$id;
							}
						}
							return $max;
					}

					function searchValueBy1($table,$field1,$field2,$value1,$value2){
	
			$res=mysqli_query($this->connect(),"select * from $table where $field1='$value1' and $field2='$value2' ");
						$array=array();
						while($row=mysqli_fetch_assoc($res)){
							$array[]=$row;
						}
							return $array;
					}



	
}	

$ob=new RegisterAction;




/*if(isset($_POST["student"])){
$id=$_POST["id"];
$name=$_POST["name"];
$contact=$_POST["contact"];
$gender=$_POST["Gender"];
$grade=$_POST["grade"];

$data=array($id,$name,$contact,$gender,$grade);
$ob->save($data,"student");

	
	
}*/


?>