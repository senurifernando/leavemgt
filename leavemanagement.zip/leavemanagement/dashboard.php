
<?php
session_start();

if(!isset($_SESSION["user"])){

	header("location:Login FORM.php");
}



?>


<!DOCTYPE html>
<html lang="en">
 <head><title> Uva Wellassa University | Leave Management System </title>
 	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1,user-scalable=no">


  <style type="text/css">

	*{box-sizing:border-box;}
	.row
	 {content:"";
	  display:table;
	  clear:both;}
	  
	.col-1{ float:left;
			width:8.33%;
			padding: 10px;
			height: 350px;
			margin:5px;
			border:2px solid#abcdab;}
	.col-2{width:16.66%;
			float:left;
			padding: 15px;
			height: 250px;
			margin:5px;
			border:2px solid #abcdab;}
	.col-3{width:25%;
			float:left;
			padding: 10px;
			height: 800px;
			margin:5px;
			border:5px solid #aabbcc;}
	.col-4{width:33.33%;
			float:left;
			padding: 10px;
			height: 500px;
			border:3px solid #abcabc;}
	.col-5{width:41.66%;
			float:left;
			padding: 10px;
			height: 300px;}
	.col-6{width:52%;
			float:left;
			padding: 10px;
			height: 300px;}
	.col-7{width:58.33%;
			float:left;
			padding: 10px;
			height: 400px;
			margin:5px;
			border:5px solid #aabbcc;}
	.col-8{width:66.66%;
			float:left;
			padding: 10px;
			height: 500px;
			margin:5px;
			border:5px solid #aabbcc;}
	.col-9{width:73%;
			float:left;
			padding: 10px;
			height: 800px;
			margin:5px;
			border:5px solid #aabbcc;}
	.col-10{width:83.33%;
			float:left;
			padding: 10px;
			height: 300px;}
	.col-11{width:91.66%;
			float:left;
			padding: 10px;
			height: 300px;}
	.col-12{width:100%;
			float:auto;
			padding: 10px;
			height: 300px;}

	.button1{
		background-color: #4CAF50;
		border: none;
		color: white;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
	}

	.button2{
		border: none;
		color: black;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 20px;
		margin: 4px 2px;
		width: 280px;
		cursor: pointer;
	}
  </style>
  

  
 			</head>
 
 					<body onload="fun('default');">
 
 
  					<script>	
  
  			function fun(v){
				var xhr=new XMLHttpRequest();
				xhr.onreadystatechange=function(){
				if(xhr.readyState==4){
       			document.getElementById("showcase").innerHTML=xhr.responseText;
	   
}
		}
		if(v!="default"){
			xhr.open("GET",v+".php",true);
			
		}else{
			
			LoadP();
		}
		

		xhr.send(null);
		return true;
		
		
	}
  
  function LoadP(){
		var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
if(xhr.readyState==4){
       document.getElementById("showcase").innerHTML=xhr.responseText;
	   //document.getElementById("btn1").style.background="gray";
		//ocument.getElementById("btn1").disabled="disabled";
}
		}
		
		xhr.open("GET","dashboard1.php",true);
		
		xhr.send(null);
		return false;
	
	
	}
	

	</script>
 	<div class="container-fluid" style="width:1280px; height:1000px; background-color: ghostwhite;margin:auto">
 		<div style="width:1280px;height:100px; background-color: lightgreen;">
				<img src="logo.png" align="left" style="width:100px; height:100px;">	
				<a  class="button2" style="float: right; background-color:  #00e64d;"  onclick="window.location='logout.php'";>Log out</a>
 		</div>

 			<div class="col-3">
 			<div> 
 			<a  class="button2" style="float: auto; background-color:  #66ff66;"onclick="fun('calendar');">My Calendar
 			</a> 
 			</div>
 			<div> 
 			
 				<a class="button2" style="float: auto; background-color: #33ff33;" onclick="fun();">Available Leaves</a>
 			</div>
 			<div> 
 				<a class="button2" style="float: auto; background-color: #1aff1a;">Pending Leaves</a>
 			</div>
 			<div> 
 				<a class="button2" style="float: auto; background-color:  #4dff88;" onclick="fun('');">Cancelled Leaves</a>
 			</div>
 			<div> 
 		<a  class="button2" style="float: auto; background-color:  #1aff66;" onclick="fun('applyLeave');">Apply for Leave</a><!--links to leave application form-->
 			</div>
 			<div> 
 				<a class="button2" style="float: auto; background-color: #00e64d;">Delete Leave Request</a>
 			</div>



 	</div>
 	<span id="showcase"></span>

 	<!--	<div  class="col-12"style="background-color: seagreen;">
 		</div> -->
 	</div>
    
	<!-- Footer -->
	<div id="grad1" style="text-align:center; margin:auto; color:#888888; font-size:12px; font-weight:bold">
		<footer>
			<p>&copy;2020 Uva Wellassa University</p>
		</footer>
	</div>
 </body>
</html>





