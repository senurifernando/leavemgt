<?php
$leaveNO=0;
$emp=$_POST["EmpID"];
$name=$_POST["Name"];
$designation=$_POST["Designation"];
$department=$_POST["Department"];
$HOD="N/A";
$officer="N/A";
$email=$_POST["Emailaddress"];
$leavetype=$_POST["type"];
$days=$_POST["Days"];
$start=$_POST["start"];
$resuming=$_POST["resuming"];
$reasons=$_POST["reasons"];
$address=$_POST["Address"];
$status="Pending";

$con=mysqli_connect("localhost","root","","leavemgt");
if ($con) {
	echo "Succeccfully connected";
		}else{
			echo "FAIL TO CONNECT";
		}
		

		$total=0;
		
		$res=mysqli_query($con,"select * from leave_form where EmployeeID='$emp'"); 
		while($row=mysqli_fetch_array($res)){
			
			$days1=$row["Days"];
			
			$total=$total+$days1;
			
		
			
		}
		
		$remain=21-$total;
		$updatedtotal=$total+$days;
if($updatedtotal<=21){
				
				$result=mysqli_query($con,"INSERT into leave_form values 
					('$leaveNO','$emp', '$name','$designation','$department','$HOD','$officer','$email',
					'$leavetype','$days','$start','$resuming','$reasons','$address','$status')");
				if ($result) {
					header("location:officerActing.php");

				}else{
					echo "Not received";
				}
				
}

else{
	
	echo "<script>alert('You can not apply for $days days, You have only  $remain leaves remaining.')</script>";
	echo "<script> window.open('officerActing.php','_self') </script>";
}
?>