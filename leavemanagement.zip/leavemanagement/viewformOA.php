
<div  class="col-9" >
<html>
<head>
	
</head>
<body>
	<form>
		
			<table border="1">
			<tr>
				<th>EmployeeID</th>
				<th>Commencing_leave</th>
				<th>Designation</th>
				<th>Department</th>
				<th>Head of the department</th>
				<th>Officer Acting</th>
				<th>No of Days</th>
				<th>Reason</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		<?php
	session_start();
	 $Department=$_SESSION["Department"];
$user=$_SESSION["user"];
$con= mysqli_connect("localhost","root","","leavemgt");
if ($con){
	
}else{
	echo "Failure";
}

$result=mysqli_query($con,"SELECT * from user_profile where UserID='$user'  ");
$Designation="null";
	while($row=mysqli_fetch_array($result)){
	$Designation=$row["Designation"];
	
	}


$result1=mysqli_query($con,"SELECT * from login where UserID='$user' ");
$id="null";
	while($row=mysqli_fetch_array($result1)){
	$id=$row["id"];
	
	}



	$result=mysqli_query($con,"SELECT * from leave_form where EmployeeID!='$id' and Department='$Department'");

	while($row=mysqli_fetch_array($result)){
	$id=$row["leave_no"];
		$a1=$row["EmployeeID"];
		$j10=$row["Commencing_leave"];
		$b2=$row["Designation"];
		$c3=$row["Department"];
		$d4=$row["HOD"];
		$e5=$row["Officer_acting"];
		$f6=$row["Days"];
		$g7=$row["Reason"];
		$h8=$row["Status"];
?>
	
			<tr>
				<td><?php echo "$a1"; ?></td>
				<td><?php echo "$j10"; ?></td>
				<td><?php echo "$b2"; ?></td>
				<td><?php echo "$c3"; ?></td>
				<td><?php echo "$d4"; ?></td>
				<td><?php echo "$e5"; ?></td>
				<td><?php echo "$f6"; ?></td>
				<td><?php echo "$g7"; ?></td>
					<td><?php echo "$h8"; ?></td>
				<td>
<?php
if($e5=="rejected"){
					?>
	<input type="button" name="accept" value="Accept" style="background-color: yellow;" onclick="window.location='approval_action.php?id=<?php echo $id;?>&action=accepted&by=Officer_acting'">
<?php
} if($e5=="accepted"){
?>
		<input type="button" name="deny" value="Reject" style="background-color: red;" onclick="window.location='approval_action.php?id=<?php echo $id;?>&action=rejected&by=Officer_acting'">	
		<?php
}
?>

<?php
if($e5=="N/A"){
					?>
		<input type="button" name="accept" value="Accept" style="background-color: yellow;" onclick="window.location='approval_action.php?id=<?php echo $id;?>&action=accepted&by=Officer_acting'">
<input type="button" name="deny" value="Reject" style="background-color: red;" onclick="window.location='approval_action.php?id=<?php echo $id;?>&action=rejected&by=Officer_acting'">	
<?php
}
?>
					<?php
if($e5=="accepted"){
					?>

				

<?php
}else{
?>

					
<?php
}
?>

				</td>
			</tr>
<?php } ?>
		</table>
	</form>
</body>
</html>
</div>