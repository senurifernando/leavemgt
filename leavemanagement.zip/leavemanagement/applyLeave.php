
<style>
	.container{
    padding-right: auto;
    padding-left: auto;
    margin-right: auto;
    margin-left: auto;
  }
  .container label{
  	display: inline-block;
  	font-family: "Arial",Sans-serif;
  	font-size: 20px;
  }
  .container input{
  	font-family: "Times New Roman",serif;
  	font-size: 20px;
  }
  .button{
  	font-size: 20px;
  	color: white;
  	background:  #3cb371;
  	 border-radius: 5px;
  }
  #corners {
  border-radius: 15px;
  border: 2px solid black;
 
}


</style>




	
<div class="container">


<div  class="col-9">
	

<body style="background-color: ghostwhite;"><h1 style="color: darkblue;">
	<center>
		Uva Wellassa University of Sri Lanka</center>
		
				<img src="logo.png" align="right" style="max-width:30%;height: auto;"></h1>
	<form align="center" action="leaveaction.php" method="post">
			<fieldset id="corners" style="background-color:aliceblue;"><table>

<?php
session_start();

$u=$_SESSION["user"];
$con= mysqli_connect("localhost","root","","leavemgt");
$result=mysqli_query($con,"SELECT * from user_profile where UserID='$u' ");

	while($row=mysqli_fetch_array($result)){
	$id=$row["id"];
	$Firstname=$row["Firstname"];
	$Designation=$row["Designation"];
	$Department=$row["Department"];
	$Email=$row["Email"];
	
	}
?>



		<label>Employee ID:  &nbsp;</label><input type="text" name="EmpID" value="<?php if(isset($id)){echo $id;} ?>"><br><br>
		<label>Name: &nbsp;</label>
		<input type="text" name="Name" value="<?php if(isset($Firstname)){echo $Firstname;} ?>"> 
		<br><br>
		<label>Designation:&nbsp;</label>
		<input type="text" name="Designation" value="<?php if(isset($Designation)){echo $Designation;} ?>">
		<br><br>
		<label>Department:&nbsp;</label>
		<input size="50px" type="text" name="Department" value="<?php if(isset($Department)){echo $Department;} ?>">
			<!--	<br><br>
			<label>Officer Acting:&nbsp;</label><input type="text" name="Officer">-->
		<br><br>
			<label>Officer Acting Email:&nbsp;</label>
			<input size="30px" type="Email" name="Emailaddress" value="<?php if(isset($Email)){echo $Email;} ?>"> 
		<br><br>
			<label>Type of leave: &nbsp;</label>
			<input type="radio" name="type" value="Casual" checked="">Casual
			<input type="radio" name="type" value="Duty" checked="">Duty
		<br><br>
			<label>Number of days: &nbsp;</label><input type="text" name="Days">
		<br><br>
			<label>Date of commnecing leave:&nbsp;</label><input type="Date" name="start">
		<br><br>
			<label>Date of resuming duties:&nbsp;</label><input type="Date" name="resuming">
		<br><br>
			<label>Reasons for leave:&nbsp;</label><textarea name="reasons" rows="4" required></textarea>
		<br><br>
			<label>Address when on leave:&nbsp;</label><textarea name="Address"rows="4" required></textarea>
		<br><br>

		</table>
		<input class="button" type="submit" name="Apply" value="Apply">
		<input class="button" type="reset" name="Cancel" value="Cancel">
			</fieldset>
	</form>
</body>




 	</div>
 </div>