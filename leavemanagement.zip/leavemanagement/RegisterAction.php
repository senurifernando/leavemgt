<?php
include("db.php");



class RegisterAction extends db{
function save($a,$table){
$res=mysqli_query($this->connect(),"insert into $table values('".implode("','",$a)."')");
if($res){
	echo"Successfully Saved";
}else{
	echo"Saving failed";
}
	
	
	
}

	
}	

$ob=new RegisterAction;


	
	
}


?>