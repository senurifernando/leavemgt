<?php

echo $id=$_GET["id"];
echo $action=$_GET["action"];
echo $by=$_GET["by"];

if(isset($_GET["uid"])){
$action=$_GET["uid"];

}

if(isset($_GET["rid"])){
$action="N/A";
$by="officer_acting";
}



	$con=mysqli_connect("localhost","root","","leavemgt");

if ($con) {
	//echo "Succeccfully connected";
		}else{
			echo "FAIL TO CONNECT";
		}
$approval=mysqli_query($con,"update leave_form set $by='$action' where leave_no='$id'");
if($approval){
	echo "updated";
}else{
	echo "not updated";
}


$result=mysqli_query($con,"SELECT * from leave_form where leave_no='$id' ");

	while($row=mysqli_fetch_array($result)){
	$hod=$row["HOD"];
	$Officer_acting=$row["Officer_acting"];
	}

if($hod!="N/A" && $Officer_acting!="N/A"){
$stt="accepted";
$approval=mysqli_query($con,"update leave_form set Status='$stt' where leave_no='$id'");
}else if($hod=="rejected"){


$stt="rejected";
$approval=mysqli_query($con,"update leave_form set Status='$stt' where leave_no='$id'");
}

?>