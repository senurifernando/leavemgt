<!DOCTYPE html>
<!-- saved from url=(0053)file:///C:/Users/Musharrif/OneDrive/Desktop/test.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style> 
		label{
			width: 250px;
			display: inline-block;
			font-size: 20px;
		}
		*{
			box-sizing: border-box;
		}
			[class*="col-"]{
				float: left;
				padding: 15px;
			}
		/*mobile phone*/
		[class*="col-"]{
			width: 100%;
		}
	</style>
		
	<title>Approved Leaves</title>
</head>
<body style="background-color: ghostwhite;">
	
		<center><h1>Approved Leaves</h1><br>
			<fieldset style="border-color: black;height:370px;width:400px;">
				
				<div="main">
					<h2>Details of the Applicant</h2>
			
				User Name: &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="UName"><br><br>
				Type of Leave: <input type="text" name="ToL"><br><br>
				Reason: &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="rsn"><br><br>
				No Of Days:&nbsp;&nbsp;&nbsp; <input type="text" name="Nday"><br><br>
				Acting officer:&nbsp; <input type="text" name="Aofficers"><br><br>
				&nbsp; &nbsp;</h4><br><br><input type="Submit" value="Back"> &nbsp; &nbsp;
				
				
				<form action="file:///C:/Users/Musharrif/OneDrive/Desktop/test.html" method="POST"></form>
				
				
				 
					</table>
				
			
		</div="main"></fieldset></center>

</body></html>