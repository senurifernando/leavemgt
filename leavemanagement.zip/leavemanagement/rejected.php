

<!DOCTYPE html>
<!-- saved from url=(0053)file:///C:/Users/Musharrif/OneDrive/Desktop/test.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style> 
		label{
			width: 250px;
			display: inline-block;
			font-size: 20px;
		}
		*{
			box-sizing: border-box;
		}
			[class*="col-"]{
				float: left;
				padding: 15px;
			}
		/*mobile phone*/
		[class*="col-"]{
			width: 100%;
		}
	</style>
		
	<title>Rejected Leaves</title>
</head>
<body style="background-color: ghostwhite;">
	
		<center><h1>Rejected  Leaves</h1><br>
			<fieldset style="border-color: black;height:330px;width:400px;">
				
				<div="main">
					<h2>Details of the Applicant</h2>
					<p>
			
				User Name: &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="UName"><br><br>
				Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="text" name="Nday"><br><br>
				Reason: &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="rsn"><br><br>
				
				
				&nbsp; &nbsp;</h4><br><br><input type="Submit" value="Back" align="right"> &nbsp; &nbsp;
				
				
				</p>
				<form action="file:///C:/Users/Musharrif/OneDrive/Desktop/test.html" method="POST"></form>
				
				
				 
					</table>
				
			
		</div="main"></fieldset></center>

</body></html>
