


<div  class="col-9" >

<div style="width:800px;height: 600px;padding-left: 200px;padding-top: 250px">
	<h2 style="font-family: Arial; text-align: center">
	Welcome To the Leave Management System</h2>

 	</div>

</div>