<!DOCTYPE html>
<!-- saved from url=(0053)file:///C:/Users/Musharrif/OneDrive/Desktop/test.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style> 
		label{
			width: 250px;
			display: inline-block;
			font-family: "Arial",Sans-serif;
			font-size: 20px;
		}
		.button{
  			font-size: 20px;
  			background:  #3cb371;
  	 		border-radius: 5px;
  				}
  		.button1{
  			font-size: 20px;
  			background:  #E0FFFF;
  	 		border-radius: 5px;
  				}
		*{
			box-sizing: border-box;
		}
			[class*="col-"]{
				float: left;
				padding: 15px;
			}
		/*mobile phone*/
		[class*="col-"]{
			width: 100%;
		}

		.corners {
 		 border-radius: 15px;
 		 border: 2px solid black;
 
		}
	</style>
		
	<title>Login FORM</title>
</head>
<body style="background-color:cornsilk;"><h1 style="color: darkblue;">
	<center>
		<img src="logo1.png" alt="University_Logo" align="center" width="150" ;height="100">
		<br>
		</center></h1>

	
		<hr color:black="">
		<center>
			<fieldset class="corners" style="border-color: black;height:450px;width:600px; background-color: lightgray;">
			<!--	<div>
					<h4>User Type</h4>
					<input type="button" value="User">
					<input type="button" value="Administrator">

				</div> -->
				<div class="main">

		<form  action="loginaction.php" method="POST">
					<h1 style="font-size: 70px;">Log In</h1>
			
				<label>User Name:</label> <input type="text" name="username"><br><br>
				<label>Password: </label><input type="Password" name="password_1">
				<br><br>
				<input type="checkbox"><label>Remember User Name</label><br><br>
				
				<input class="button" type="button" value="Sign Up" onclick="window.location='register.php'"> &nbsp; &nbsp;
				<input class="button" type="submit" value="Login" name="Login" >&nbsp; &nbsp;
				<input class="button" type="Reset" value="Clear"><table caption="Login Prompt"><br>
					<h4><label>Forgot Password!</label>&nbsp; &nbsp;
<input class="button1" type="button" value="Click Here" onclick="window.location='ResetPassword.php' ">
				</h4><br><br>
	
			
		</form>
				
 				
				 
					</table>
				
			
		</div="main">
	</fieldset>
</center>

</body></html>