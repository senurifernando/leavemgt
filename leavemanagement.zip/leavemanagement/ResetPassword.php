<!DOCTYPE html>
<html>
 <head>
	<title>Reset Password</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
		.header2 {
  width: 30%;
  margin: 50px auto 0px;
  color: white;
  background: #3cb371;
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
		form{
			 border-radius: 0px 0px 10px 10px;
			 padding-right: 20px;
			 padding-left: 20px;
			 padding-top: none;
			 background-color: #e6ffe6;
			 text-align:center;
		}
	</style>
 </head>
 
 <body>
 	<div class="header">
  	<h2>Reset Password</h2>
  </div>
	
	<form  action="model.php" method="POST" style="">
		<table>
			<div class="input-group">
			<tr>
		<td><label>User Name :</label></td>
		<td><input type="text" name="username"></td>
		</tr>
	</div>
		<div class="input-group">
			<tr>
		 <td><label>New Password :</label></td> 
		 <td><input type="Password" name="password" ></td>
		</tr>
		</div>
			<div class="input-group">
				<tr>
		<td><label>Confirm Password :</label></td>
		 <td><input type="Password" name="cpass"  ></td>
				</tr>
			<div class="input-group">
				<tr>
		<td><input class="btn" type="Submit" value="Reset" name="ResetPassword" ></td>
		<td><input class="btn" type="Reset" value="Clear"></td>
				</tr>
			</div>
		</table>

	</form>
	
 </body>
</html>