<?php
session_start();

  $user=$_POST["username"];
  $pass=$_POST["password_1"];

$con=mysqli_connect("localhost","root","","leavemgt");

	$res=mysqli_query($con,"select * from login,user_profile where login.UserID='$user' and Password='$pass' and login.UserID=user_profile.UserID");
	$b=false;
	$ut="null";

		while($row=mysqli_fetch_array($res)){
			$b=true;
			
			
			$ut=$row["UserType"];
			$des=$row["Designation"];
			$_SESSION["Designation"]=$des;	
			 $_SESSION["Department"]=$row["Department"];
			
}


	if($b){
		$_SESSION["user"]=$user;
		if($ut=="admin")
			{
			header("location:admin.php");
			}else if($ut=="Head of the Department"){

			header("location:hod.php");
		}else{

			header("location:officerActing.php");
		}
		
}
	else{
	header("location:Login FORM.php");
	}


?>