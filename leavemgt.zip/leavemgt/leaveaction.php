<?php
$emp=$_POST["EmpID"];

$con=mysqli_connect("localhost","root","","leavemgt");
?>